import processing.core.PApplet;

public class Knap{
    boolean knaptrykket; PApplet p; float x; float y; float b; float h; float t; String knapText;

    Knap(PApplet p, float x, float y, float b, float h, float t, String knapText){
      this.p = p; this.x=x; this.y=y; this.b=b; this.h=h; this.t=t; this.knapText=knapText;
    }
    void tegnknap(){
        if(knaptrykket)p.fill(225, 132, 132);else p.fill(225, 132, 132);
        p.noStroke();
        p.rect(x,y,b,h,t);
        p.fill(102,0,51);
        p.textSize(15);
        p.text(this.knapText,x+5,y+5,110,70);
    }
    void registrerKlik(float x, float y){
        if(x<this.x+b&&x>this.x&&y<this.y+h&&y>this.y)
            knaptrykket=!knaptrykket;
    }

    boolean erKnapTrykket(){return knaptrykket;}
}

