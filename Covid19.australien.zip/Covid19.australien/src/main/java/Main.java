import processing.data.Table;
import processing.data.TableRow;
import processing.core.PApplet;



public class Main extends PApplet {
    Table tableA;
    Billeder aus;
    talTabel tabel;
    stat stat;
    Restriktioner res;
    Knap knap;
    Knap restriktioner;
    int distX = 1;
    int distY = 890;
    boolean start = false;
    boolean NSW = false; boolean NT = false; boolean QLD = false; boolean SA = false; boolean TAS = false; boolean VIC = false; boolean WA = false;
    boolean ResNSW = false; boolean ResNT = false; boolean ResQLD = false; boolean ResSA = false; boolean ResTAS = false; boolean ResVIC = false; boolean ResWA = false;
    boolean billeder = false;


    public static void main(String[] args) {
        PApplet.main("Main");


    }

    public void settings() {
        super.settings();
        size(1000, 900);

    }

    public void setup() {
        super.setup();
        background(234, 246, 250);
        tableA = loadTable("HeleAus.csv", "header");
        aus = new Billeder(this);
        tabel = new talTabel(this);
        stat = new stat(this);
        res = new Restriktioner(this);
        knap = new Knap(this, 20, 30, 75, 30, 5, "Back");
        restriktioner = new Knap(this, 20, 150, 125, 30, 5, "Restrictions");
        println(tableA.getRowCount() + " total rows aus");
        aus.Load();
        start = true;
        billeder = true;

    }

    public void draw() {
        if (billeder == true){
            clear();
            background(234, 246, 250);
            tabel.TegnTabel();
            textSize(50);
            fill(240, 194, 194);
            text("Covid-19 in Australia", 250, 70);
            imageMode(CORNERS);
            image(aus.WA, 214, 221, 451, 533);
            image(aus.SA, 452, 401, 621, 582);
            image(aus.NT, 452, 186, 577, 400);
            image(aus.QLD, 578, 181, 786, 437);
            image(aus.NSW, 622, 426, 786, 573);
            image(aus.VIC, 622, 527, 744, 595);
            image(aus.TAS, 651, 630, 706, 685);
        }
        if (start == false) {
            knap.tegnknap();
            restriktioner.tegnknap();
        }
        stat.graf(aus, NSW, NT, QLD, SA, TAS, VIC, WA);
        res.rest(ResNSW,ResNT, ResQLD, ResSA, ResTAS, ResVIC, ResWA);
        int lastRowC = 0;
        int lastRowD = 0;
        for (int k = 0; k < tableA.getRowCount(); k++) {
            TableRow rr = tableA.getRow(k);
            String dateA = rr.getString("date");
            int confirmedA = rr.getInt("confirmed");
            int deathA = rr.getInt("deaths");
            int diffC = confirmedA - lastRowC;
            int diffD = deathA - lastRowD;
            lastRowC = confirmedA;
            lastRowD = deathA;
            if (start == true) {
                fill(240, 194, 194);
                noStroke();
                rect((k * (width - 5) / tableA.getRowCount()) + distX, distY, (width - 5) / tableA.getRowCount()-1, -confirmedA / 125);
                fill(225, 132, 132);
                rect((k * (width - 5) / tableA.getRowCount()) + distX, distY, (width - 5) / tableA.getRowCount()-1, -deathA / 125);

                if (mouseX > k * (width - 5) / tableA.getRowCount() + distX && mouseX < k * (width - 5) / tableA.getRowCount() + distX + 4 && mouseY > 600) {
                    textSize(15);
                    fill(231, 126, 126);
                    text(dateA, 153, 600);
                    text(diffC, 153, 645);
                    text(diffD, 153, 690);
                    text(confirmedA, 153, 735);
                    text(deathA, 153, 780);
                }
            }
        }


    }


    public void mousePressed() {

        knap.registrerKlik(mouseX, mouseY);
        restriktioner.registrerKlik(mouseX, mouseY);

        if (knap.erKnapTrykket()) {
            start = true;
            NSW = false; NT = false; QLD = false; SA = false; TAS = false; VIC = false; WA = false;
            ResNSW = false;ResNT = false; ResQLD = false; ResSA = false; ResTAS = false; ResVIC = false; ResWA = false;
            billeder = true;
        }

        if (get(mouseX, mouseY) == -1533272 || get(mouseX, mouseY) == -1533273) {
            clear();
            start = false;
            NSW = true;
            billeder = false;
            background(234, 246, 250);
        }

        if (get(mouseX, mouseY) == -1539189) {
            clear();
            start = false;
            NT = true;
            billeder = false;
            background(234, 246, 250);
        }
        int QLDColor1 = -1541748;
        int QLDColor2 = -1542004;
        if (get(mouseX, mouseY) == QLDColor2 || get(mouseX, mouseY) == QLDColor1) {
            start = false;
            QLD = true;
            billeder = false;
            background(234, 246, 250);
        }
        if (get(mouseX, mouseY) == -1670509) {
            start = false;
            SA = true;
            billeder = false;
            background(234, 246, 250);
        }
        if (get(mouseX, mouseY) == -2267274) {
            start = false;
            TAS = true;
            billeder = false;
            background(234, 246, 250);
        }
        if (get(mouseX, mouseY) == -28766) {
            start = false;
            VIC = true;
            billeder = false;
            background(234, 246, 250);
        }
        if (get(mouseX, mouseY) == -1875854) {
            start = false;
            WA = true;
            billeder = false;
            background(234, 246, 250);
        }

        if (restriktioner.erKnapTrykket()&&NSW == true){
            ResNSW = true; }
        if (restriktioner.erKnapTrykket()&&NT == true){
            ResNT = true;}
        if (restriktioner.erKnapTrykket()&&QLD == true){
            ResQLD = true;
        }
        if (restriktioner.erKnapTrykket()&&SA == true){
            ResSA = true;
        }
        if (restriktioner.erKnapTrykket()&&TAS == true){
            ResTAS = true;
        }
        if (restriktioner.erKnapTrykket()&&VIC == true){
            ResVIC = true;
        }
        if (restriktioner.erKnapTrykket()&&WA == true){
            ResWA = true;
        }




    }
    }