import processing.data.Table;
import processing.data.TableRow;
import processing.core.PApplet;


public class stat {
    PApplet st;
    Table tableS;
    int distX = 1;
    int distY = 890;
    int countNSW;
    int countNT;
    int countQLD;
    int countSA;
    int countTAS;
    int countVIC;
    int countWA;
    int lastRowCS = 0;
    int lastRowDS = 0;

    stat(PApplet st) {
        this.st = st;
    }

    void graf(Billeder aus, boolean NSW, boolean NT, boolean QLD, boolean SA, boolean TAS, boolean VIC, boolean WA) {

        tableS = st.loadTable("covid_data.csv", "header");
        countNSW = 0;
        countNT = 0;
        countQLD = 0;
        countSA = 0;
        countTAS = 0;
        countVIC = 0;
        countWA = 0;
        for (int i = 0; i < (tableS.getRowCount()); i++) {
            TableRow r = tableS.getRow(i);
            int confirmedS = r.getInt("confirmed");
            int deathS = r.getInt("deaths");
            String stateS = r.getString("state_abbrev");
            lastRowCS = confirmedS;
            lastRowDS = deathS;
            if (NSW == true) {
                st.image(aus.NSW, 700, 150, 900, 350);
                st.textSize(50);
                st.fill(240, 194, 194);
                st.text("Covid-19 in New South Wales", 175, 70);
                st.rect(50, 660, 30, 30);
                st.fill(225, 132, 132);
                st.rect(50, 710, 30, 30);
                st.fill(102, 0, 51);
                st.textSize(20);
                st.text("current date: 2020-10-25", 50,640);
                st.text("Confirmed cases: 4382", 110, 680);
                st.text("Total deaths: 53", 110, 730);
                if (stateS.equals("NSW")) {
                    countNSW++;
                    st.noStroke();
                    st.fill(240, 194, 194);
                    st.rect((countNSW * (st.width - 10) / (tableS.getRowCount() / 8)) + distX, distY, (st.width - 10) / (tableS.getRowCount() / 8) - 1, -confirmedS / 32);
                    st.fill(225, 132, 132);
                    st.rect((countNSW * (st.width - 10) / (tableS.getRowCount() / 8)) + distX, distY, (st.width - 10) / (tableS.getRowCount() / 8) - 1, -deathS / 32);

                }
            }

            if (NT == true) {
                st.image(aus.NT, 750, 150, 875, 350);
                st.textSize(50);
                st.fill(240, 194, 194);
                st.text("Covid-19 in Northern territory", 175, 70);
                st.rect(50, 660, 30, 30);
                st.fill(225, 132, 132);
                st.rect(50, 710, 30, 30);
                st.fill(102, 0, 51);
                st.textSize(20);
                st.text("current date: 2020-10-25", 50,640);
                st.text("Confirmed cases: 33", 110, 680);
                st.text("Total deaths: 0", 110, 730);
                if (stateS.equals("NT")) {
                    countNT++;
                    st.fill(240, 194, 194);
                    st.noStroke();
                    st.rect((countNT * (st.width - 10) / (tableS.getRowCount() / 8)) + distX, distY, (st.width - 10) / (tableS.getRowCount() / 8) - 1, -confirmedS);
                    st.fill(225, 132, 132);
                    st.rect((countNT * (st.width - 10) / (tableS.getRowCount() / 8)) + distX, distY, (st.width - 10) / (tableS.getRowCount() / 8) - 1, -deathS);
                }
            }
            if (QLD == true) {
                st.image(aus.QLD, 700, 150, 900, 400);
                st.textSize(50);
                st.fill(240, 194, 194);
                st.text("Covid-19 in Queensland", 175, 70);
                st.rect(50, 660, 30, 30);
                st.fill(225, 132, 132);
                st.rect(50, 710, 30, 30);
                st.fill(102, 0, 51);
                st.textSize(20);
                st.text("current date: 2020-10-25", 50,640);
                st.text("Confirmed cases: 1167", 110, 680);
                st.text("Total deaths: 6", 110, 730);
                if (stateS.equals("QLD")) {
                    countQLD++;
                    st.fill(240, 194, 194);
                    st.noStroke();
                    st.rect((countQLD * (st.width - 10) / (tableS.getRowCount() / 8)) + distX, distY, (st.width - 10) / (tableS.getRowCount() / 8) - 1, -confirmedS / 30);
                    st.fill(225, 132, 132);
                    st.rect((countQLD * (st.width - 10) / (tableS.getRowCount() / 8)) + distX, distY, (st.width - 10) / (tableS.getRowCount() / 8) - 1, -deathS / 30);
                }
            }
            if (SA == true) {
                st.image(aus.SA, 700, 150, 900, 360);
                st.textSize(50);
                st.fill(240, 194, 194);
                st.text("Covid-19 in South Australia", 175, 70);
                st.rect(50, 660, 30, 30);
                st.fill(225, 132, 132);
                st.rect(50, 710, 30, 30);
                st.fill(102, 0, 51);
                st.textSize(20);
                st.text("current date: 2020-10-25", 50,640);
                st.text("Confirmed cases: 491", 110, 680);
                st.text("Total deaths: 4", 110, 730);
                if (stateS.equals("SA")) {
                    countSA++;
                    st.fill(240, 194, 194);
                    st.noStroke();
                    st.rect((countSA * (st.width - 10) / (tableS.getRowCount() / 8)) + distX, distY, (st.width - 10) / (tableS.getRowCount() / 8) - 1, -confirmedS / 30);
                    st.fill(225, 132, 132);
                    st.rect((countSA * (st.width - 10) / (tableS.getRowCount() / 8)) + distX, distY, (st.width - 10) / (tableS.getRowCount() / 8) - 1, -deathS / 30);
                }
            }
            if (TAS == true) {
                st.image(aus.TAS, 750, 150, 850, 250);
                st.textSize(50);
                st.fill(240, 194, 194);
                st.text("Covid-19 in Tasmania", 175, 70);
                st.rect(50, 660, 30, 30);
                st.fill(225, 132, 132);
                st.rect(50, 710, 30, 30);
                st.fill(102, 0, 51);
                st.textSize(20);
                st.text("current date: 2020-10-25", 50,640);
                st.text("Confirmed cases: 230", 110, 680);
                st.text("Total deaths: 13", 110, 730);
                if (stateS.equals("TAS")) {
                    countTAS++;
                    st.fill(240, 194, 194);
                    st.noStroke();
                    st.rect((countTAS * (st.width - 10) / (tableS.getRowCount() / 8)) + distX, distY, (st.width - 10) / (tableS.getRowCount() / 8) - 1, -confirmedS / 30);
                    st.fill(225, 132, 132);
                    st.rect((countTAS * (st.width - 10) / (tableS.getRowCount() / 8)) + distX, distY, (st.width - 10) / (tableS.getRowCount() / 8) - 1, -deathS / 30);
                }
            }
            if (VIC == true) {
                st.image(aus.VIC, 750, 150, 900, 250);
                st.textSize(50);
                st.fill(240, 194, 194);
                st.text("Covid-19 in Victoria", 225, 70);
                st.rect(50, 660, 30, 30);
                st.fill(225, 132, 132);
                st.rect(50, 710, 30, 30);
                st.fill(102, 0, 51);
                st.textSize(20);
                st.text("current date: 2020-10-25", 50,640);
                st.text("Confirmed cases: 20343", 110, 680);
                st.text("Total deaths: 817", 110, 730);
                if (stateS.equals("VIC")) {
                    countVIC++;
                    st.fill(240, 194, 194);
                    st.noStroke();
                    st.rect((countVIC * (st.width - 10) / (tableS.getRowCount() / 8)) + distX, distY, (st.width - 10) / (tableS.getRowCount() / 8) - 1, -confirmedS / 35);
                    st.fill(225, 132, 132);
                    st.rect((countVIC * (st.width - 10) / (tableS.getRowCount() / 8)) + distX, distY, (st.width - 10) / (tableS.getRowCount() / 8) - 1, -deathS / 35);
                }
            }
            if (WA == true) {
                st.image(aus.WA, 650, 150, 900, 462);
                st.textSize(50);
                st.fill(240, 194, 194);
                st.text("Covid-19 in West Australia", 175, 70);
                st.rect(50, 660, 30, 30);
                st.fill(225, 132, 132);
                st.rect(50, 710, 30, 30);
                st.fill(102, 0, 51);
                st.textSize(20);
                st.text("current date: 2020-10-25", 50,640);
                st.text("Confirmed cases: 760", 110, 680);
                st.text("Total deaths: 9", 110, 730);
                if (stateS.equals("WA")) {
                    countWA++;
                    st.fill(240, 194, 194);
                    st.noStroke();
                    st.rect((countWA * (st.width - 10) / (tableS.getRowCount() / 8)) + distX, distY, (st.width - 10) / (tableS.getRowCount() / 8) - 1, -confirmedS / 30);
                    st.fill(225, 132, 132);
                    st.rect((countWA * (st.width - 10) / (tableS.getRowCount() / 8)) + distX, distY, (st.width - 10) / (tableS.getRowCount() / 8) - 1, -deathS / 30);
                }
            }
        }
    }
}




