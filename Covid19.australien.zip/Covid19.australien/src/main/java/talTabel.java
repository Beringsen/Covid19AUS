import processing.core.PApplet;

public class talTabel {
    PApplet tab;

    talTabel(PApplet tab){this.tab=tab;}

    void TegnTabel(){
        tab.noStroke();
        tab.fill(254, 230, 230);
        tab.rect(50, 560, 300,225);
        tab.fill(250, 234, 234);
        tab.rect(150, 605, 200,180);
        tab.textSize(15);
        tab.fill(231, 126, 126);
        tab.text("Dato", 53, 600);
        tab.text("Smittede", 53, 645);
        tab.text("Døde", 53, 690);
        tab.text("Smittede i alt", 53, 735);
        tab.text("Døde i alt", 53, 780);
        tab.stroke(255);
        tab.strokeWeight(2);
        tab.line(150, 560, 150, 785);
        tab.line(50,605 , 350, 605);
        tab.line(50,650 , 350, 650);
        tab.line(50,695 , 350, 695);
        tab.line(50,740 , 350, 740);


    }

}
