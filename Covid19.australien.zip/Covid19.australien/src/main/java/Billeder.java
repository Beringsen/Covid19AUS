import processing.core.PImage;
import processing.core.PApplet;

public class Billeder {
    PImage aus; PImage NSW; PImage NT; PImage QLD; PImage SA; PImage TAS; PImage VIC; PImage WA;
    PApplet img;

    Billeder(PApplet img) {this.img=img;}
        void Load() {
            aus = img.loadImage("Aus.png");
            NSW = img.loadImage("NSW.png");
            WA = img.loadImage("WA.png");
            SA = img.loadImage("SA.png");
            NT = img.loadImage("NT.png");
            QLD = img.loadImage("QLD.png");
            TAS = img.loadImage("Tas.png");
            VIC = img.loadImage("VIC.png");

        }

}
