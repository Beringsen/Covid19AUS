import processing.core.PApplet;

public class Restriktioner {
 PApplet res;

    Restriktioner(PApplet res) {
        this.res = res;
    }

 void rest(boolean ResNSW, boolean ResNT, boolean ResQLD, boolean ResSA, boolean ResTAS, boolean ResVIC, boolean ResWA) {
     if (ResNSW == true) {
         res.fill(240, 194, 194);
         res.rect(20, 180, 530, 350, 5);
         res.textSize(15);
         res.fill(102, 0, 51);
         res.text("Up to 30 people can gather in an outdoor public place.", 30, 210);
         res.text("A protest or demonstration about governmental or political matters of \nno more than 500 people will be permitted in an outdoor \npublic place.", 30, 245);
         res.text("Hospitality venues such as restaurants, cafes, pubs and clubs can take \ngroup bookings of up to 30 customers per booking and up \nto 30 customers per table. ", 30, 320);
         res.text("Places of worship and religious services can have up to 300 people, \nsubject to the 4 square metre rule, provided a COVID-19 \nSafety Plan is in place.", 30, 405);
         res.text("Gyms will be required to have a COVID-19 safety hygiene marshal on \nduty only when there are more than 20 people in the gym at one time. ", 30, 490);
     }
     if (ResNT == true) {
         res.fill(240, 194, 194);
         res.rect(20, 180, 530, 150, 5);
         res.textSize(15);
         res.fill(102, 0, 51);
         res.text("The North Territory currently has no restrictions\n since they've had so few cases", 30, 210);

     }
     if (ResQLD == true) {
         res.fill(240, 194, 194);
         res.rect(20, 180, 530, 300, 5);
         res.textSize(15);
         res.fill(102, 0, 51);
         res.text("Up to 40 people at a time can dance at a wedding\nheld under a COVID Safe Plan or Checklist.", 30, 210);
         res.text("People can dance at year 12 school formals and end of year 12 events.", 30, 270);
         res.text("Allow only 1 person per 4 square metres indoors.", 30, 310);
         res.text("Allow only 1 person per 2 square metres outdoors.", 30, 350);
         res.text("The Direction has been updated to allow a maximum of 40 people \nto gather in Queensland residences, non-residences and in \noutdoor settings (for example, a public park).", 30, 390);
     }
     if (ResSA == true) {
         res.fill(240, 194, 194);
         res.rect(20, 180, 530, 300, 5);
         res.textSize(15);
         res.fill(102, 0, 51);
         res.text("Gatherings at private residences may have up to \n50 people per gathering.", 30, 210);
         res.text("Gatherings at a private place (other than a private residence) \nare restricted to no more than 150 people.", 30, 270);
         res.text("Gatherings including private functions at relevant licensed premises, \nweddings and funerals may have up to 150 people per gathering.", 30, 330);
         res.text("The maximum number of people permitted at private residences at \nany one time for a private gathering is 50.", 30, 390);
     }
     if (ResTAS == true) {
         res.fill(240, 194, 194);
         res.rect(20, 180, 535, 275, 5);
         res.textSize(15);
         res.fill(102, 0, 51);
         res.text("Gathering limits are now determined by the density of the area, up to \na maximum of: 250 people for an undivided space in an indoor \npremises; and 1,000 people in the outdoor space of the premises.", 30, 210);
         res.text("Business restrictions have changed to allow standing activities \n– like darts, pool, eight-ball, snooker and karaoke – in licensed venues.", 30, 295);
         res.text("People attending an event in a licensed venue can move around freely, \nas long as they are not standing and drinking alcohol.", 30, 355);
     }
     if (ResVIC == true) {
         res.fill(240, 194, 194);
         res.rect(20, 180, 530, 375, 5);
         res.textSize(15);
         res.fill(102, 0, 51);
         res.text("There are no restrictions on the reasons to leave home.", 30, 210);
         res.text("If you can’t work from home, you can go to work.", 30, 250);
         res.text("You can see friends and family outdoors in a public place \nin a group of up to 10 people.", 30, 290);
         res.text("Up to two people can visit a household once per day. \nThe two people may be from different households.", 30, 350);
         res.text("Shops are open. While shopping you need to respect the limit of \nallowed patrons in a shop. This limit ensures everyone in the \nshop can keep 1.5 metres distance.", 30, 410);
         res.text("Indoor physical recreation can resume for adults, with class sizes \nof up to 10 per session. Equipment must be cleaned between uses. \nYou should wear a face mask unless you are out of breath.", 30, 500);
     }
     if (ResWA == true) {
         res.fill(240, 194, 194);
         res.rect(20, 180, 545, 250, 5);
         res.textSize(15);
         res.fill(102, 0, 51);
         res.text("Gathering limits are only determined by WA’s 2 square metre rule.", 30, 210);
         res.text("Major events permitted, subject to having an approved COVID Event Plan.", 30, 250);
         res.text("Unseated performances are permitted at venues such as concert halls, \nlive music venues, bars, pubs and nightclubs.", 30, 290);
         res.text("Gyms operating unstaffed, but regular cleaning must be maintained.", 30, 350);
     }
 }
}

